# MSAE — Système de Gestion des Agents
**Mutuelle de Santé des Agents de l'État**

---

## 📁 Structure du projet

```
msae-projet/
├── index.html          ← Page principale (ouvrir dans le navigateur)
├── css/
│   └── style.css       ← Toutes les règles de style (thème clair + sombre)
├── js/
│   └── app.js          ← Toute la logique applicative (commentée)
├── .vscode/
│   └── settings.json   ← Configuration recommandée VS Code
└── README.md           ← Ce fichier
```

---

## 🚀 Démarrage rapide

### Option 1 — Ouvrir directement dans le navigateur
1. Double-cliquez sur `index.html`
2. Le site s'ouvre immédiatement dans Chrome / Firefox / Edge

### Option 2 — Via VS Code avec Live Server (recommandé)
1. Ouvrez le dossier `msae-projet/` dans VS Code
   → `Fichier > Ouvrir le dossier`
2. Installez l'extension **Live Server** (voir ci-dessous)
3. Clic droit sur `index.html` → **"Open with Live Server"**
4. Le site s'ouvre sur `http://127.0.0.1:5500`

---

## 🔧 Extensions VS Code recommandées

| Extension | Utilité |
|-----------|---------|
| **Live Server** (Ritwick Dey) | Recharge automatique à chaque sauvegarde |
| **Prettier** | Formatage automatique du code |
| **Auto Rename Tag** | Renomme les balises HTML paires |
| **IntelliCode** | Autocomplétion intelligente |

Pour les installer : `Ctrl+Shift+X` → rechercher le nom → Installer

---

## 📋 Fonctionnalités

### Gestion des agents
- ✅ Ajouter un nouvel agent
- ✅ Modifier les informations d'un agent
- ✅ Supprimer un agent (avec confirmation)
- ✅ Filtrer par ministère, statut ou recherche libre

### Pièces et documents
- ✅ Cocher les pièces fournies (attestation, naissance, photo)
- ✅ Valider le paiement de l'adhésion (2 500 FCFA)
- ✅ Valider le paiement de la carte magnétique (5 000 FCFA)

### Calcul automatique des cotisations
- ✅ Saisir la date de début de cotisation
- ✅ Le nombre de mois est calculé automatiquement
- ✅ Total des cotisations = salaire indiciaire × 2% × nombre de mois
- ✅ Mise à jour automatique toutes les minutes

### Statuts automatiques
| Statut | Condition |
|--------|-----------|
| **Inéligible** | Pièces manquantes ou adhésion non payée |
| **En attente** | Moins de 6 mois de cotisation |
| **Actif** | Toutes conditions remplies (≥ 6 mois) |

### Carte magnétique
- Émise uniquement si l'agent est **Actif** ET a payé les **5 000 FCFA**
- Valable pour l'agent et ses ayants droit avec dossier **complet**

### Ayants droit
| Type | Pièces requises |
|------|-----------------|
| Épouse | Acte de naissance + Certificat de mariage + Photo |
| Enfant (< 18 ans) | Acte de naissance + Photo |
| Enfant (18–21 ans) | Acte de naissance + Photo + Attestation d'inscription |
| Enfant (> 21 ans) | ❌ Non éligible |
| Parents (Père/Mère) | Acte de naissance + Justificatif lien familial + Photo |
| Enfant sous tutelle | Acte de naissance + Certificat d'adoption/prise en charge + Photo |

### Rapport
- Vue consolidée par ministère
- Nombre d'agents actifs, en attente, inéligibles
- Total des cotisations collectées par ministère

---

## 🎨 Thème

L'application supporte automatiquement le **mode sombre** selon les préférences système (via `prefers-color-scheme`).

---

## 📝 Modifier les données

Les données d'exemple sont dans `js/app.js` au début du fichier (tableau `agents`).
Pour ajouter des ministères, modifiez le tableau `MINISTERES` dans `js/app.js`.

---

## 🌐 Publier en ligne (GitHub Pages)

```bash
git init
git add .
git commit -m "MSAE — Système de gestion des agents"
git remote add origin https://github.com/VOTRE_NOM/msae-gestion.git
git push -u origin main
```
Puis dans GitHub : **Settings → Pages → Source: main / root → Save**

---

*Projet MSAE — Niger*
