/* ============================================================
   MSAE — Mutuelle de Santé des Agents de l'État
   Logique applicative principale — app.js
   ============================================================ */

/* ────────────────────────────────────────────────
   1. DONNÉES INITIALES (exemples de démonstration)
   ──────────────────────────────────────────────── */

let agents = [
  {
    id: 1,
    nom: "Ibrahim Mahamane",
    ministere: "Ministère des Finances",
    matricule: "FIN-2022-014",
    salaire: 185000,
    mois: 8,
    dateDebut: "2023-08-01",
    pieces: {
      attestation: true,
      naissance: true,
      photo: true,
      adhesion: true,
      carte: true
    },
    ayants: [
      {
        type: "Épouse",
        nom: "Fatouma Mahamane",
        age: 0,
        lienParent: "",
        pieces: { naissance: true, mariage: true, photo: true }
      },
      {
        type: "Enfant",
        nom: "Ali Mahamane",
        age: 10,
        lienParent: "",
        pieces: { naissance: true, photo: true }
      }
    ]
  },
  {
    id: 2,
    nom: "Aissatou Garba",
    ministere: "Ministère de l'Éducation",
    matricule: "EDU-2023-087",
    salaire: 142000,
    mois: 3,
    dateDebut: "2025-01-01",
    pieces: {
      attestation: true,
      naissance: true,
      photo: true,
      adhesion: true,
      carte: false
    },
    ayants: []
  },
  {
    id: 3,
    nom: "Oumarou Souley",
    ministere: "Ministère de la Santé",
    matricule: "SAN-2021-032",
    salaire: 210000,
    mois: 12,
    dateDebut: "2024-04-01",
    pieces: {
      attestation: true,
      naissance: true,
      photo: false,
      adhesion: true,
      carte: true
    },
    ayants: [
      {
        type: "Parents",
        nom: "Halima Souley",
        age: 65,
        lienParent: "Mère",
        pieces: { naissance: true, lien: true, photo: true }
      }
    ]
  }
];

let nextId  = 4;      // Compteur auto-incrémenté pour les IDs
let editId  = null;   // ID de l'agent en cours de modification (null = nouvel agent)

/* Liste des ministères disponibles */
const MINISTERES = [
  "Ministère de la Santé",
  "Ministère de l'Éducation",
  "Ministère des Finances",
  "Ministère de la Justice",
  "Ministère de l'Intérieur",
  "Ministère de la Défense",
  "Ministère des Transports",
  "Autre ministère"
];


/* ────────────────────────────────────────────────
   2. CALCUL DES COTISATIONS ET MOIS
   ──────────────────────────────────────────────── */

/**
 * Calcule le nombre de mois écoulés depuis une date de début.
 * @param {string} dateDebut - Date au format YYYY-MM-DD
 * @returns {number} Nombre de mois (≥ 0)
 */
function calcMoisDepuis(dateDebut) {
  if (!dateDebut) return 0;
  const debut = new Date(dateDebut);
  const now   = new Date();
  return Math.max(
    0,
    (now.getFullYear() - debut.getFullYear()) * 12 +
    (now.getMonth()   - debut.getMonth())
  );
}

/**
 * Met à jour automatiquement le nombre de mois cotisés
 * de tous les agents ayant une date de début et ayant payé l'adhésion.
 */
function autoUpdateCotisations() {
  agents.forEach(a => {
    if (a.dateDebut && a.pieces.adhesion) {
      a.mois = calcMoisDepuis(a.dateDebut);
    }
  });
}

// Mise à jour immédiate au chargement
autoUpdateCotisations();

// Mise à jour automatique toutes les 60 secondes
setInterval(() => {
  autoUpdateCotisations();
  renderAgents();
}, 60000);

/**
 * Recalcule les mois cotisés à partir du champ date du formulaire.
 */
function calcMoisAuto() {
  const d = document.getElementById('f-date-debut').value;
  if (d) {
    document.getElementById('f-mois').value = calcMoisDepuis(d);
  }
  calcCotisation();
}

/**
 * Recalcule le total des cotisations (salaire × 2% × mois).
 */
function calcCotisation() {
  const s = parseFloat(document.getElementById('f-salaire').value) || 0;
  const m = parseFloat(document.getElementById('f-mois').value)    || 0;
  document.getElementById('f-cotisation-total').value =
    (s * 0.02 * m).toLocaleString() + ' FCFA';
}


/* ────────────────────────────────────────────────
   3. LOGIQUE DE STATUT ET D'ÉLIGIBILITÉ
   ──────────────────────────────────────────────── */

/**
 * Détermine le statut d'un agent.
 * - "ineligible" : pièces manquantes ou adhésion non payée
 * - "attente"    : moins de 6 mois de cotisation
 * - "actif"      : toutes conditions remplies
 */
function getStatut(a) {
  const piecesBase = a.pieces.attestation && a.pieces.naissance && a.pieces.photo;
  if (!piecesBase || !a.pieces.adhesion) return "ineligible";
  if (a.mois < 6) return "attente";
  return "actif";
}

/**
 * Détermine si la carte magnétique peut être émise.
 * @returns {"ok"|"nok"|null}
 */
function getCarteStatut(a) {
  if (getStatut(a) !== "actif") return null;
  return a.pieces.carte ? "ok" : "nok";
}

/**
 * Vérifie si un ayant droit est éligible (âge ≤ 21 ans pour les enfants).
 */
function ayantEligible(ay) {
  if (ay.type === "Enfant" && ay.age > 21) return false;
  return true;
}

/**
 * Vérifie si le dossier d'un ayant droit est complet.
 * Règles par type :
 *   Épouse   → naissance + mariage + photo
 *   Enfant   → naissance + photo (+ inscription si 18–21 ans)
 *   Parents  → naissance + lien familial + photo
 *   Tutelle  → naissance + adoption/prise en charge + photo
 */
function ayantComplet(ay) {
  if (!ayantEligible(ay)) return false;

  if (ay.type === "Épouse")
    return ay.pieces.naissance && ay.pieces.mariage && ay.pieces.photo;

  if (ay.type === "Enfant") {
    const baseOk = ay.pieces.naissance && ay.pieces.photo;
    if (ay.age >= 18 && ay.age <= 21) return baseOk && ay.pieces.inscription;
    return baseOk;
  }

  if (ay.type === "Parents")
    return ay.pieces.naissance && ay.pieces.lien && ay.pieces.photo;

  if (ay.type === "Tutelle")
    return ay.pieces.naissance && ay.pieces.adoption && ay.pieces.photo;

  return false;
}


/* ────────────────────────────────────────────────
   4. NAVIGATION PAR ONGLETS
   ──────────────────────────────────────────────── */

function showTab(t) {
  document.getElementById('tab-agents').style.display  = t === 'agents'  ? 'block' : 'none';
  document.getElementById('tab-rapport').style.display = t === 'rapport' ? 'block' : 'none';
  document.querySelectorAll('.nav button').forEach((b, i) => {
    b.classList.toggle('active',
      (i === 0 && t === 'agents') || (i === 1 && t === 'rapport')
    );
  });
  if (t === 'rapport') renderRapport();
}


/* ────────────────────────────────────────────────
   5. INITIALISATION DU FILTRE MINISTÈRE
   ──────────────────────────────────────────────── */

function initMinistereFilter() {
  const sel = document.getElementById('filter-ministere');
  MINISTERES.forEach(m => {
    const o = document.createElement('option');
    o.value = m;
    o.textContent = m;
    sel.appendChild(o);
  });
}


/* ────────────────────────────────────────────────
   6. RENDU DES STATISTIQUES
   ──────────────────────────────────────────────── */

function renderStats() {
  const total   = agents.length;
  const actifs  = agents.filter(a => getStatut(a) === 'actif').length;
  const attente = agents.filter(a => getStatut(a) === 'attente').length;
  const cartes  = agents.filter(a => getCarteStatut(a) === 'ok').length;

  document.getElementById('stats-bar').innerHTML = `
    <div class="stat">
      <div class="stat-n blue">${total}</div>
      <div class="stat-l">Total agents</div>
    </div>
    <div class="stat">
      <div class="stat-n green">${actifs}</div>
      <div class="stat-l">Actifs (bénéficiaires)</div>
    </div>
    <div class="stat">
      <div class="stat-n amber">${attente}</div>
      <div class="stat-l">En attente</div>
    </div>
    <div class="stat">
      <div class="stat-n">${cartes}</div>
      <div class="stat-l">Cartes émises</div>
    </div>
  `;
}


/* ────────────────────────────────────────────────
   7. RENDU DE LA LISTE DES AGENTS
   ──────────────────────────────────────────────── */

function renderAgents() {
  const mf = document.getElementById('filter-ministere').value;
  const sf = document.getElementById('filter-statut').value;
  const q  = (document.getElementById('search').value || '').toLowerCase();

  const list = agents.filter(a => {
    if (mf && a.ministere !== mf) return false;
    if (sf && getStatut(a) !== sf) return false;
    if (q && !a.nom.toLowerCase().includes(q) &&
             !a.matricule.toLowerCase().includes(q)) return false;
    return true;
  });

  renderStats();
  const el = document.getElementById('agents-list');

  if (!list.length) {
    el.innerHTML = '<div class="empty-state">Aucun agent trouvé</div>';
    return;
  }

  el.innerHTML = list.map(a => agentCardHTML(a)).join('');
}

/**
 * Génère le HTML d'une carte agent.
 */
function agentCardHTML(a) {
  const st       = getStatut(a);
  const cs       = getCarteStatut(a);
  const initials = a.nom.split(' ').map(x => x[0]).join('').slice(0, 2).toUpperCase();
  const prog     = Math.min(100, Math.round((a.mois / 6) * 100));
  const cotTotal = a.salaire * 0.02 * a.mois;

  const badgeCls = st === 'actif' ? 'green' : st === 'attente' ? 'amber' : 'red';
  const badgeTxt = st === 'actif' ? 'Actif' : st === 'attente' ? 'En attente' : 'Inéligible';

  // Pièces de base de l'agent
  const pRows = [
    ["Attestation de travail",       a.pieces.attestation],
    ["Acte/certificat de naissance", a.pieces.naissance],
    ["Photo d'identité",             a.pieces.photo],
  ].map(([l, v]) =>
    `<div class="check-row">
      <input type="checkbox" ${v ? 'checked' : ''} disabled> ${l}
    </div>`
  ).join('');

  // Informations financières
  const finRows = `
    <div class="check-row">
      <input type="checkbox" ${a.pieces.adhesion ? 'checked' : ''} disabled>
      Adhésion payée (2 500 FCFA)
    </div>
    <div class="check-row">
      <input type="checkbox" ${a.pieces.carte ? 'checked' : ''} disabled>
      Carte magnétique (5 000 FCFA)
    </div>
    <div class="fin-row">
      <span>Salaire indiciaire</span>
      <span>${a.salaire.toLocaleString()} FCFA</span>
    </div>
    <div class="fin-row">
      <span>Début cotisation</span>
      <span>${a.dateDebut ? new Date(a.dateDebut).toLocaleDateString('fr-FR') : '—'}</span>
    </div>
    <div class="fin-row">
      <span>Mois cotisés</span>
      <span>${a.mois} mois <span style="font-size:10px;color:var(--txt2)">(auto)</span></span>
    </div>
    <div class="fin-row">
      <span>Total cotisations (2%)</span>
      <span>${cotTotal.toLocaleString()} FCFA</span>
    </div>
  `;

  // Ayants droit
  const ayantRows = a.ayants.map(ay => {
    if (!ayantEligible(ay)) {
      return `
        <div style="display:flex;justify-content:space-between;font-size:11px;padding:2px 0">
          <span>${ay.type} — ${ay.nom} (${ay.age} ans)</span>
          <span class="badge red">Non éligible (+21 ans)</span>
        </div>`;
    }
    const ok        = ayantComplet(ay);
    const lienLabel = (ay.type === 'Parents' && ay.lienParent)
      ? ` (${ay.lienParent})` : '';
    return `
      <div style="display:flex;justify-content:space-between;font-size:11px;padding:2px 0">
        <span>${ay.type}${lienLabel} — ${ay.nom}</span>
        <span class="badge ${ok ? 'green' : 'red'}">${ok ? 'Complet' : 'Incomplet'}</span>
      </div>`;
  }).join('') || '<span style="font-size:11px;color:var(--txt2)">Aucun ayant droit</span>';

  // Statut de la carte magnétique
  let carteInfo = '';
  if (st === 'actif') {
    carteInfo = cs === 'ok'
      ? '<div class="card-status ok">Carte émise — valable pour agent et ayants droit complets</div>'
      : '<div class="card-status nok">Paiement carte (5 000 FCFA) non effectué — pas de carte</div>';
  } else if (st === 'attente') {
    carteInfo = `
      <div class="card-status wait">
        <div style="width:100%">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span>En attente — ${a.mois}/6 mois cotisés</span>
          </div>
          <div class="cotisation-bar">
            <div class="cotisation-fill" style="width:${prog}%"></div>
          </div>
        </div>
      </div>`;
  } else {
    carteInfo = '<div class="card-status nok">Dossier incomplet — vérifier les pièces et le paiement d\'adhésion</div>';
  }

  return `
    <div class="agent-card">
      <div class="agent-header">
        <div class="avatar">${initials}</div>
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <span class="agent-name">${a.nom}</span>
            <span class="badge ${badgeCls}">${badgeTxt}</span>
            <span class="tag">${a.matricule}</span>
          </div>
          <div class="agent-min">${a.ministere}</div>
        </div>
      </div>
      <div class="agent-body">
        <div>
          <div class="section-title">Pièces agent</div>
          ${pRows}
        </div>
        <div>
          <div class="section-title">Conditions financières</div>
          ${finRows}
        </div>
      </div>
      ${a.ayants.length
        ? `<div style="margin-top:10px">
             <div class="section-title">Ayants droit (${a.ayants.length})</div>
             ${ayantRows}
           </div>`
        : ''}
      ${carteInfo}
      <div class="agent-actions">
        <button class="btn" onclick="openModal(${a.id})">Modifier</button>
        <button class="btn danger" onclick="confirmDelete(${a.id})">Supprimer</button>
      </div>
    </div>`;
}


/* ────────────────────────────────────────────────
   8. GESTION DES AYANTS DROIT (FORMULAIRE)
   ──────────────────────────────────────────────── */

/**
 * Génère le HTML d'un bloc ayant droit dans le formulaire.
 */
function buildAyantHTML(id, d) {
  const lienOpts = ['Père', 'Mère']
    .map(v => `<option ${(d.lienParent || '') === v ? 'selected' : ''}>${v}</option>`)
    .join('');

  return `
    <div class="ayant-header" style="flex-wrap:wrap;gap:4px">
      <select
        onchange="updateAyantPieces('${id}', this.value)"
        style="font-size:12px;padding:4px 8px;border:0.5px solid var(--bdr2);
               border-radius:var(--radius);background:var(--bg);color:var(--txt)">
        ${['Épouse', 'Enfant', 'Parents', 'Tutelle']
          .map(t => `<option ${d.type === t ? 'selected' : ''}>${t}</option>`)
          .join('')}
      </select>

      <!-- Sélecteur Père / Mère (visible uniquement pour "Parents") -->
      <select
        class="ay-lien"
        style="font-size:12px;padding:4px 8px;border:0.5px solid var(--bdr2);
               border-radius:var(--radius);background:var(--bg);color:var(--txt);
               display:${d.type === 'Parents' ? 'inline-block' : 'none'}">
        ${lienOpts}
      </select>

      <input
        placeholder="Nom"
        value="${d.nom || ''}"
        class="ay-nom"
        style="flex:1;min-width:80px;margin:0 4px;font-size:12px;padding:4px 8px;
               border:0.5px solid var(--bdr2);border-radius:var(--radius);
               background:var(--bg);color:var(--txt)">

      <input
        placeholder="Âge"
        type="number"
        value="${d.age || ''}"
        class="ay-age"
        oninput="updateAyantPieces('${id}', document.querySelector('#${id} select').value)"
        style="width:60px;font-size:12px;padding:4px 8px;border:0.5px solid var(--bdr2);
               border-radius:var(--radius);background:var(--bg);color:var(--txt)">

      <button
        onclick="document.getElementById('${id}').remove()"
        style="padding:2px 8px;border:0.5px solid var(--bdr2);border-radius:var(--radius);
               background:var(--bg);cursor:pointer;font-size:11px;
               color:var(--txt2);margin-left:4px">✕</button>
    </div>
    <div class="check-group ay-pieces" id="pieces_${id}"></div>`;
}

/**
 * Ajoute un ayant droit au formulaire.
 * @param {object|null} data - Données existantes (pour modification) ou null (pour ajout)
 */
function addAyant(data) {
  const id = 'ay_' + Date.now() + '_' + Math.floor(Math.random() * 9999);
  const d  = data || { type: 'Épouse', nom: '', age: '', lienParent: '', pieces: {} };

  const el = document.createElement('div');
  el.className = 'ayant-card';
  el.id        = id;
  el.innerHTML = buildAyantHTML(id, d);
  document.getElementById('ayants-container').appendChild(el);
  updateAyantPieces(id, d.type);

  // Restaurer les cases cochées si données existantes
  if (data && data.pieces) {
    setTimeout(() => {
      const container = document.getElementById('pieces_' + id);
      if (container) {
        container.querySelectorAll('[data-key]').forEach(cb => {
          cb.checked = !!data.pieces[cb.dataset.key];
        });
      }
    }, 30);
  }
}

/**
 * Met à jour les pièces requises selon le type d'ayant droit et l'âge.
 * Règles :
 *   Épouse  → naissance, mariage, photo
 *   Enfant  → naissance, photo (+ inscription si 18–21 ans)
 *             → avertissement si > 21 ans (non éligible)
 *   Parents → naissance, lien familial, photo
 *   Tutelle → naissance, adoption/prise en charge, photo
 */
function updateAyantPieces(id, type) {
  const container = document.getElementById('pieces_' + id);
  if (!container) return;

  const age    = parseInt(document.querySelector('#' + id + ' .ay-age')?.value) || 0;
  const lienSel = document.querySelector('#' + id + ' .ay-lien');
  if (lienSel) lienSel.style.display = type === 'Parents' ? 'inline-block' : 'none';

  let pieces = [];

  if (type === 'Épouse') {
    pieces = [
      ['naissance', 'Acte de naissance'],
      ['mariage',   'Certificat de mariage'],
      ['photo',     'Photo']
    ];
  } else if (type === 'Enfant') {
    if (age > 21) {
      container.innerHTML =
        `<div style="font-size:11px;padding:4px 8px;background:var(--red-bg);
                     color:var(--red-txt);border-radius:var(--radius)">
           Enfant de plus de 21 ans — non éligible aux prestations
         </div>`;
      return;
    }
    pieces = [
      ['naissance', 'Acte de naissance'],
      ['photo',     'Photo']
    ];
    if (age >= 18) pieces.push(['inscription', "Attestation d'inscription"]);

  } else if (type === 'Parents') {
    pieces = [
      ['naissance', 'Acte de naissance'],
      ['lien',      'Justificatif lien familial'],
      ['photo',     'Photo']
    ];
  } else if (type === 'Tutelle') {
    pieces = [
      ['naissance', 'Acte de naissance'],
      ['adoption',  "Certificat d'adoption/prise en charge"],
      ['photo',     'Photo']
    ];
  }

  container.innerHTML = pieces
    .map(([k, l]) =>
      `<label class="check-item">
        <input type="checkbox" data-key="${k}"> ${l}
       </label>`)
    .join('');
}

/**
 * Récupère les ayants droit saisis dans le formulaire.
 */
function getAyantsFromForm() {
  return Array.from(
    document.querySelectorAll('#ayants-container .ayant-card')
  ).map(el => {
    const type       = el.querySelector('select').value;
    const nom        = el.querySelector('.ay-nom').value;
    const age        = parseInt(el.querySelector('.ay-age').value) || 0;
    const lienParent = type === 'Parents'
      ? (el.querySelector('.ay-lien')?.value || '')
      : '';
    const pieces = {};
    el.querySelectorAll('[data-key]').forEach(cb => {
      pieces[cb.dataset.key] = cb.checked;
    });
    return { type, nom, age, lienParent, pieces };
  });
}


/* ────────────────────────────────────────────────
   9. MODAL AJOUT / MODIFICATION
   ──────────────────────────────────────────────── */

/**
 * Ouvre le modal. Si id est fourni, charge les données de l'agent existant.
 */
function openModal(id) {
  editId = id || null;
  document.getElementById('modal-title').textContent =
    id ? "Modifier l'agent" : "Nouvel agent";
  document.getElementById('ayants-container').innerHTML = '';

  if (id) {
    // Mode modification — charger les données
    const a = agents.find(x => x.id === id);
    document.getElementById('f-nom').value       = a.nom;
    document.getElementById('f-ministere').value = a.ministere;
    document.getElementById('f-matricule').value = a.matricule;
    document.getElementById('f-salaire').value   = a.salaire;
    document.getElementById('f-date-debut').value = a.dateDebut || '';
    calcMoisAuto();

    document.getElementById('p-attestation').checked = a.pieces.attestation;
    document.getElementById('p-naissance').checked   = a.pieces.naissance;
    document.getElementById('p-photo').checked       = a.pieces.photo;
    document.getElementById('p-adhesion').checked    = a.pieces.adhesion;
    document.getElementById('p-carte').checked       = a.pieces.carte;

    calcCotisation();
    a.ayants.forEach(ay => addAyant(ay));

  } else {
    // Mode création — réinitialiser le formulaire
    ['f-nom', 'f-matricule', 'f-salaire', 'f-cotisation-total', 'f-date-debut']
      .forEach(fid => { document.getElementById(fid).value = ''; });
    ['p-attestation', 'p-naissance', 'p-photo', 'p-adhesion', 'p-carte']
      .forEach(fid => { document.getElementById(fid).checked = false; });
    document.getElementById('f-mois').value = 0;
  }

  document.getElementById('modal').style.display = 'flex';
}

/** Ferme le modal d'ajout/modification. */
function closeModal() {
  document.getElementById('modal').style.display = 'none';
}

/**
 * Enregistre l'agent (création ou mise à jour).
 */
function saveAgent() {
  const nom = document.getElementById('f-nom').value.trim();
  if (!nom) {
    alert("Veuillez saisir le nom de l'agent");
    return;
  }

  const data = {
    nom,
    ministere:  document.getElementById('f-ministere').value,
    matricule:  document.getElementById('f-matricule').value,
    salaire:    parseFloat(document.getElementById('f-salaire').value) || 0,
    dateDebut:  document.getElementById('f-date-debut').value,
    mois:       parseInt(document.getElementById('f-mois').value) || 0,
    pieces: {
      attestation: document.getElementById('p-attestation').checked,
      naissance:   document.getElementById('p-naissance').checked,
      photo:       document.getElementById('p-photo').checked,
      adhesion:    document.getElementById('p-adhesion').checked,
      carte:       document.getElementById('p-carte').checked,
    },
    ayants: getAyantsFromForm(),
  };

  if (editId) {
    const i = agents.findIndex(a => a.id === editId);
    agents[i] = { ...agents[i], ...data };
  } else {
    agents.push({ id: nextId++, ...data });
  }

  closeModal();
  renderAgents();
}


/* ────────────────────────────────────────────────
   10. SUPPRESSION D'UN AGENT
   ──────────────────────────────────────────────── */

function confirmDelete(id) {
  const a = agents.find(x => x.id === id);
  document.getElementById('confirm-title').textContent = "Supprimer l'agent";
  document.getElementById('confirm-msg').textContent   =
    `Êtes-vous sûr de vouloir supprimer ${a.nom} ?`;

  document.getElementById('confirm-ok').onclick = () => {
    agents = agents.filter(x => x.id !== id);
    document.getElementById('confirm-modal').style.display = 'none';
    renderAgents();
  };

  document.getElementById('confirm-modal').style.display = 'flex';
}


/* ────────────────────────────────────────────────
   11. RAPPORT PAR MINISTÈRE
   ──────────────────────────────────────────────── */

function renderRapport() {
  const byMin = {};

  agents.forEach(a => {
    if (!byMin[a.ministere]) {
      byMin[a.ministere] = {
        total: 0, actifs: 0, attente: 0, ineligible: 0, cartes: 0, cotisations: 0
      };
    }
    const st = getStatut(a);
    byMin[a.ministere].total++;
    byMin[a.ministere][st]++;
    if (getCarteStatut(a) === 'ok') byMin[a.ministere].cartes++;
    byMin[a.ministere].cotisations += a.salaire * 0.02 * a.mois;
  });

  let html = '<div style="font-size:15px;font-weight:500;margin-bottom:14px">Rapport par ministère</div>';

  Object.entries(byMin).forEach(([min, stats]) => {
    html += `
      <div class="agent-card" style="margin-bottom:10px">
        <div style="font-weight:500;margin-bottom:8px">${min}</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));gap:8px">
          <div class="stat"><div class="stat-n blue">${stats.total}</div><div class="stat-l">Agents</div></div>
          <div class="stat"><div class="stat-n green">${stats.actifs}</div><div class="stat-l">Actifs</div></div>
          <div class="stat"><div class="stat-n amber">${stats.attente}</div><div class="stat-l">En attente</div></div>
          <div class="stat"><div class="stat-n red">${stats.ineligible}</div><div class="stat-l">Inéligibles</div></div>
          <div class="stat"><div class="stat-n">${stats.cartes}</div><div class="stat-l">Cartes</div></div>
          <div class="stat">
            <div class="stat-n" style="font-size:14px">${stats.cotisations.toLocaleString()}</div>
            <div class="stat-l">Cotisations FCFA</div>
          </div>
        </div>
      </div>`;
  });

  if (!Object.keys(byMin).length)
    html += '<div class="empty-state">Aucun agent enregistré</div>';

  document.getElementById('rapport-content').innerHTML = html;
}


/* ────────────────────────────────────────────────
   12. INITIALISATION AU CHARGEMENT DE LA PAGE
   ──────────────────────────────────────────────── */

initMinistereFilter();
renderAgents();
